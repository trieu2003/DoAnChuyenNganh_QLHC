

const ChemicalUsageManagement = () => {
  return <div>Quản Lý Sử Dụng Hóa Chất</div>;
};

export default ChemicalUsageManagement;

