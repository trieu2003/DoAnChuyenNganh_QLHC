

const ChemicalForecasting = () => {
  return <div>Dự Trù Hóa Chất</div>;
};

export default ChemicalForecasting;
