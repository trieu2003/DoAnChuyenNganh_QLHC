

const Settings = () => {
  return <div>Cài Đặt</div>;
};

export default Settings;
