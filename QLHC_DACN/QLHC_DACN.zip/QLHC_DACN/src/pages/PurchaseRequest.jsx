
const PurchaseRequest = () => {
  return <div>Đề Xuất Mua Hóa Chất</div>;
};

export default PurchaseRequest;
