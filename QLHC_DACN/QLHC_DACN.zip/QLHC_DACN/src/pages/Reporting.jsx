const Reporting = () => {
  return <div>Thống Kê & Báo Cáo</div>;
};

export default Reporting;

