

const ExpiredChemicalManagement = () => {
  return <div>Thanh Lý Hóa Chất Hết Hạn</div>;
};

export default ExpiredChemicalManagement;
