// // import React, { useState, useEffect } from 'react';
// // import axios from 'axios';

// // const PhieuThanhLyForm = ({ initialData, onClose, onRefresh }) => {
// //   const [lyDo, setLyDo] = useState(initialData?.lyDo || "");
// //   const [trangThai, setTrangThai] = useState(initialData?.trangThai || "");
// //   const [phuongThucThanhLy, setPhuongThucThanhLy] = useState(initialData?.phuongThucThanhLy || "");
// //   const [maNguoiDung, setMaNguoiDung] = useState(initialData?.maNguoiDung || "");

// //   useEffect(() => {
// //     if (initialData) {
// //       setLyDo(initialData.lyDo);
// //       setTrangThai(initialData.trangThai);
// //       setPhuongThucThanhLy(initialData.phuongThucThanhLy);
// //       setMaNguoiDung(initialData.maNguoiDung);
// //     }
// //   }, [initialData]);

// //   const handleSubmit = async (e) => {
// //     e.preventDefault();
// //     const data = { lyDo: lyDo, trangThai: trangThai, phuongThucThanhLy: phuongThucThanhLy, maNguoiDung: maNguoiDung };

// //     try {
// //       if (initialData) {
// //         await axios.put(`https://localhost:7240/api/PhieuThanhLy/${initialData.maPhieuTL}`, data);
// //         alert('Cập nhật phiếu thanh lý thành công');
// //       } else {
// //         await axios.post('https://localhost:7240/api/PhieuThanhLy', data);
// //         alert('Tạo phiếu thanh lý thành công');
// //       }
// //       onRefresh(); // Làm mới danh sách sau khi thêm/sửa
// //       onClose();
// //     } catch (error) {
// //       console.error("Có lỗi khi cập nhật/ tạo phiếu thanh lý:", error);
// //       alert("Lỗi khi thực hiện thao tác.");
// //     }
// //   };

// //   return (
// //     <div className="modal">
// //       <div className="modal-content p-8 bg-white rounded-lg shadow-lg">
// //         <h2 className="text-2xl font-bold mb-6">{initialData ? "Cập Nhật Phiếu Thanh Lý" : "Tạo Phiếu Thanh Lý"}</h2>
// //         <form onSubmit={handleSubmit}>
// //           <div className="mb-4">
// //             <label htmlFor="lyDo" className="block text-sm font-medium text-gray-700">Lý Do</label>
// //             <input
// //               type="text"
// //               id="lyDo"
// //               value={lyDo}
// //               onChange={(e) => setLyDo(e.target.value)}
// //               className="mt-1 block w-full px-4 py-2 border rounded-md"
// //               required
// //             />
// //           </div>
// //           <div className="mb-4">
// //             <label htmlFor="trangThai" className="block text-sm font-medium text-gray-700">Trạng Thái</label>
// //             <input
// //               type="text"
// //               id="trangThai"
// //               value={trangThai}
// //               onChange={(e) => setTrangThai(e.target.value)}
// //               className="mt-1 block w-full px-4 py-2 border rounded-md"
// //               required
// //             />
// //           </div>
// //           <div className="mb-4">
// //             <label htmlFor="phuongThucThanhLy" className="block text-sm font-medium text-gray-700">Phương Thức Thanh Lý</label>
// //             <input
// //               type="text"
// //               id="phuongThucThanhLy"
// //               value={phuongThucThanhLy}
// //               onChange={(e) => setPhuongThucThanhLy(e.target.value)}
// //               className="mt-1 block w-full px-4 py-2 border rounded-md"
// //               required
// //             />
// //           </div>
// //           <div className="mb-6">
// //             <label htmlFor="maNguoiDung" className="block text-sm font-medium text-gray-700">Mã Người Dùng</label>
// //             <input
// //               type="number"
// //               id="maNguoiDung"
// //               value={maNguoiDung}
// //               onChange={(e) => setMaNguoiDung(e.target.value)}
// //               className="mt-1 block w-full px-4 py-2 border rounded-md"
// //               required
// //             />
// //           </div>
// //           <div className="flex justify-end space-x-4">
// //             <button
// //               type="button"
// //               onClick={onClose}
// //               className="bg-gray-500 text-white px-6 py-2 rounded-md"
// //             >
// //               Hủy
// //             </button>
// //             <button
// //               type="submit"
// //               className="bg-blue-500 text-white px-6 py-2 rounded-md"
// //             >
// //               Lưu
// //             </button>
// //           </div>
// //         </form>
// //       </div>
// //     </div>
// //   );
// // };

// // export default PhieuThanhLyForm;
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// const PhieuThanhLyForm = ({ initialData, onClose, onRefresh }) => {
//   const [lyDo, setLyDo] = useState(initialData?.lyDo || "");
//   const [trangThai, setTrangThai] = useState(initialData?.trangThai || "");
//   const [phuongThucThanhLy, setPhuongThucThanhLy] = useState(initialData?.phuongThucThanhLy || "");
//   const [maNguoiDung, setMaNguoiDung] = useState(initialData?.maNguoiDung || "");
//   const [userMaNguoiDung, setUserMaNguoiDung] = useState(localStorage.getItem("maNguoiDung")); // Lấy mã người dùng từ localStorage

//   useEffect(() => {
//     if (initialData) {
//       setLyDo(initialData.lyDo);
//       setTrangThai(initialData.trangThai);
//       setPhuongThucThanhLy(initialData.phuongThucThanhLy);
//       setMaNguoiDung(initialData.maNguoiDung);
//     }
//   }, [initialData]);

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     // Kiểm tra xem mã người dùng có trùng với người đăng nhập không
//     if (maNguoiDung !== data.maNguoiDung) {
//       alert("Bạn không có quyền sửa phiếu thanh lý này.");
//       return;
//     }

//     const data = { lyDo: lyDo, trangThai: trangThai, phuongThucThanhLy: phuongThucThanhLy, maNguoiDung: maNguoiDung };

//     try {
//       if (initialData) {
//         await axios.put(`https://localhost:7240/api/PhieuThanhLy/${initialData.maPhieuTL}`, data);
//         alert('Cập nhật phiếu thanh lý thành công');
//       } else {
//         await axios.post('https://localhost:7240/api/PhieuThanhLy', data);
//         alert('Tạo phiếu thanh lý thành công');
//       }
//       onRefresh(); // Làm mới danh sách sau khi thêm/sửa
//       onClose();
//     } catch (error) {
//       console.error("Có lỗi khi cập nhật/ tạo phiếu thanh lý:", error);
//       alert("Lỗi khi thực hiện thao tác.");
//     }
//   };

//   return (
//     <div className="modal">
//       <div className="modal-content p-8 bg-white rounded-lg shadow-lg">
//         <h2 className="text-2xl font-bold mb-6">{initialData ? "Cập Nhật Phiếu Thanh Lý" : "Tạo Phiếu Thanh Lý"}</h2>
//         <form onSubmit={handleSubmit}>
//           <div className="mb-4">
//             <label htmlFor="lyDo" className="block text-sm font-medium text-gray-700">Lý Do</label>
//             <input
//               type="text"
//               id="lyDo"
//               value={lyDo}
//               onChange={(e) => setLyDo(e.target.value)}
//               className="mt-1 block w-full px-4 py-2 border rounded-md"
//               required
//             />
//           </div>
//           <div className="mb-4">
//             <label htmlFor="trangThai" className="block text-sm font-medium text-gray-700">Trạng Thái</label>
//             <input
//               type="text"
//               id="trangThai"
//               value={trangThai}
//               onChange={(e) => setTrangThai(e.target.value)}
//               className="mt-1 block w-full px-4 py-2 border rounded-md"
//               required
//             />
//           </div>
//           <div className="mb-4">
//             <label htmlFor="phuongThucThanhLy" className="block text-sm font-medium text-gray-700">Phương Thức Thanh Lý</label>
//             <input
//               type="text"
//               id="phuongThucThanhLy"
//               value={phuongThucThanhLy}
//               onChange={(e) => setPhuongThucThanhLy(e.target.value)}
//               className="mt-1 block w-full px-4 py-2 border rounded-md"
//               required
//             />
//           </div>
//           <div className="mb-6">
//             <label htmlFor="maNguoiDung" className="block text-sm font-medium text-gray-700">Mã Người Dùng</label>
//             <input
//               type="number"
//               id="maNguoiDung"
//               value={maNguoiDung}
//               onChange={(e) => setMaNguoiDung(e.target.value)}
//               className="mt-1 block w-full px-4 py-2 border rounded-md"
//               required
//             />
//           </div>
//           <div className="flex justify-end space-x-4">
//             <button
//               type="button"
//               onClick={onClose}
//               className="bg-gray-500 text-white px-6 py-2 rounded-md"
//             >
//               Hủy
//             </button>
//             <button
//               type="submit"
//               className="bg-blue-500 text-white px-6 py-2 rounded-md"
//             >
//               Lưu
//             </button>
//           </div>
//         </form>
//       </div>
//     </div>
//   );
// };

// export default PhieuThanhLyForm;
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const PhieuThanhLyForm = ({ initialData, onClose, onRefresh }) => {
  const [lyDo, setLyDo] = useState(initialData?.lyDo || "");
  const [trangThai, setTrangThai] = useState(initialData?.trangThai || "");
  const [phuongThucThanhLy, setPhuongThucThanhLy] = useState(initialData?.phuongThucThanhLy || "");
  const [maNguoiDung, setMaNguoiDung] = useState(initialData?.maNguoiDung || "");
  const [userMaNguoiDung, setUserMaNguoiDung] = useState(parseInt(localStorage.getItem("maNguoiDung"))); // Lấy mã người dùng từ localStorage
console.log("userMaNguoiDung", userMaNguoiDung);
  // Thiết lập các giá trị khi initialData thay đổi
  useEffect(() => {
    if (initialData) {
      setLyDo(initialData.lyDo);
      setTrangThai(initialData.trangThai);
      setPhuongThucThanhLy(initialData.phuongThucThanhLy);
      setMaNguoiDung(initialData.maNguoiDung);
    }
  }, [initialData]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Kiểm tra xem mã người dùng có trùng với người đăng nhập không
    if (parseInt(maNguoiDung) !== userMaNguoiDung) {
      console.log("Ma nguoi dung khong trung voi nguoi dang nhap", maNguoiDung, userMaNguoiDung);
      alert("Bạn không có quyền sửa phiếu thanh lý này.");
      return;
    }

    const data = { lyDo: lyDo, trangThai: trangThai, phuongThucThanhLy: phuongThucThanhLy, maNguoiDung: maNguoiDung };

    try {
      if (initialData) {
        await axios.put(`https://localhost:7240/api/PhieuThanhLy/${initialData.maPhieuTL}`, data);
        alert('Cập nhật phiếu thanh lý thành công');
      } else {
        await axios.post('https://localhost:7240/api/PhieuThanhLy', data);
        alert('Tạo phiếu thanh lý thành công');
      }
      onRefresh(); // Làm mới danh sách sau khi thêm/sửa
      onClose();
    } catch (error) {
      console.error("Có lỗi khi cập nhật/ tạo phiếu thanh lý:", error);
      alert("Lỗi khi thực hiện thao tác.");
    }
  };

  return (
    <div className="modal">
      <div className="modal-content p-8 bg-white rounded-lg shadow-lg">
        <h2 className="text-2xl font-bold mb-6">{initialData ? "Cập Nhật Phiếu Thanh Lý" : "Tạo Phiếu Thanh Lý"}</h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label htmlFor="lyDo" className="block text-sm font-medium text-gray-700">Lý Do</label>
            <input
              type="text"
              id="lyDo"
              value={lyDo}
              onChange={(e) => setLyDo(e.target.value)}
              className="mt-1 block w-full px-4 py-2 border rounded-md"
              required
            />
          </div>
          <div className="mb-4">
            <label htmlFor="trangThai" className="block text-sm font-medium text-gray-700">Trạng Thái</label>
            <input
              type="text"
              id="trangThai"
              value={trangThai}
              onChange={(e) => setTrangThai(e.target.value)}
              className="mt-1 block w-full px-4 py-2 border rounded-md"
              required
            />
          </div>
          <div className="mb-4">
            <label htmlFor="phuongThucThanhLy" className="block text-sm font-medium text-gray-700">Phương Thức Thanh Lý</label>
            <input
              type="text"
              id="phuongThucThanhLy"
              value={phuongThucThanhLy}
              onChange={(e) => setPhuongThucThanhLy(e.target.value)}
              className="mt-1 block w-full px-4 py-2 border rounded-md"
              required
            />
          </div>
          <div className="mb-6">
            <label htmlFor="maNguoiDung" className="block text-sm font-medium text-gray-700">Mã Người Dùng</label>
            <input
              type="number"
              id="maNguoiDung"
              value={maNguoiDung}
              onChange={(e) => setMaNguoiDung(e.target.value)}
              className="mt-1 block w-full px-4 py-2 border rounded-md"
              required
            />
          </div>
          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={onClose}
              className="bg-gray-500 text-white px-6 py-2 rounded-md"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="bg-blue-500 text-white px-6 py-2 rounded-md"
            >
              Lưu
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PhieuThanhLyForm;
