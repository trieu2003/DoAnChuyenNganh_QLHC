// // import React, { useState } from 'react';
// // import axios from 'axios';

// // const CreatePhieuThanhLyForm = ({ onClose, onRefresh }) => {
// //   const [lyDo, setLyDo] = useState('');
// //   const [trangThai, setTrangThai] = useState('');
// //   const [phuongThucThanhLy, setPhuongThucThanhLy] = useState('');
// //   const [maNguoiDung, setMaNguoiDung] = useState('');
// //   const [error, setError] = useState('');

// //   // Hàm gửi yêu cầu tạo phiếu thanh lý
// //   const handleSubmit = async (e) => {
// //     e.preventDefault();
// //     setError(''); // Reset error

// //     if (!lyDo || !trangThai || !phuongThucThanhLy || !maNguoiDung) {
// //       setError('Vui lòng điền đầy đủ thông tin');
// //       return;
// //     }

// //     const newPhieu = {
// //       LyDo: lyDo,
// //       TrangThai: trangThai,
// //       PhuongThucThanhLy: phuongThucThanhLy,
// //       MaNguoiDung: maNguoiDung,
// //     };

// //     try {
// //       const response = await axios.post('https://localhost:7240/api/PhieuThanhLy', newPhieu);
// //       alert('Tạo phiếu thanh lý thành công!');
// //       onRefresh(); // Làm mới danh sách
// //       onClose();   // Đóng form
// //     } catch (error) {
// //       console.error('Có lỗi khi tạo phiếu thanh lý:', error);
// //       setError('Có lỗi khi tạo phiếu thanh lý, vui lòng thử lại.');
// //     }
// //   };

// //   return (
// //     <div className="modal">
// //       <div className="modal-content p-8 bg-white rounded-lg shadow-lg">
// //         <h2 className="text-2xl font-bold mb-6">Tạo Phiếu Thanh Lý</h2>
        
// //         {/* Hiển thị lỗi nếu có */}
// //         {error && <div className="text-red-500 mb-4">{error}</div>}

// //         <form onSubmit={handleSubmit}>
// //           <div className="mb-4">
// //             <label htmlFor="lyDo" className="block text-sm font-medium text-gray-700">Lý Do</label>
// //             <input
// //               type="text"
// //               id="lyDo"
// //               value={lyDo}
// //               onChange={(e) => setLyDo(e.target.value)}
// //               className="mt-1 block w-full px-4 py-2 border rounded-md"
// //               required
// //             />
// //           </div>

// //           <div className="mb-4">
// //             <label htmlFor="trangThai" className="block text-sm font-medium text-gray-700">Trạng Thái</label>
// //             <input
// //               type="text"
// //               id="trangThai"
// //               value={trangThai}
// //               onChange={(e) => setTrangThai(e.target.value)}
// //               className="mt-1 block w-full px-4 py-2 border rounded-md"
// //               required
// //             />
// //           </div>

// //           <div className="mb-4">
// //             <label htmlFor="phuongThucThanhLy" className="block text-sm font-medium text-gray-700">Phương Thức Thanh Lý</label>
// //             <input
// //               type="text"
// //               id="phuongThucThanhLy"
// //               value={phuongThucThanhLy}
// //               onChange={(e) => setPhuongThucThanhLy(e.target.value)}
// //               className="mt-1 block w-full px-4 py-2 border rounded-md"
// //               required
// //             />
// //           </div>

// //           <div className="mb-6">
// //             <label htmlFor="maNguoiDung" className="block text-sm font-medium text-gray-700">Mã Người Dùng</label>
// //             <input
// //               type="number"
// //               id="maNguoiDung"
// //               value={maNguoiDung}
// //               onChange={(e) => setMaNguoiDung(e.target.value)}
// //               className="mt-1 block w-full px-4 py-2 border rounded-md"
// //               required
// //             />
// //           </div>

// //           <div className="flex justify-end space-x-4">
// //             <button
// //               type="button"
// //               onClick={onClose}
// //               className="bg-gray-500 text-white px-6 py-2 rounded-md"
// //             >
// //               Hủy
// //             </button>
// //             <button
// //               type="submit"
// //               className="bg-blue-500 text-white px-6 py-2 rounded-md"
// //             >
// //               Lưu
// //             </button>
// //           </div>
// //         </form>
// //       </div>
// //     </div>
// //   );
// // };

// // export default CreatePhieuThanhLyForm;
// import React, { useState } from 'react';
// import axios from 'axios';

// const CreatePhieuThanhLyForm = ({ onClose, onRefresh }) => {
//   const [lyDo, setLyDo] = useState('');
//   const [trangThai, setTrangThai] = useState('');
//   const [phuongThucThanhLy, setPhuongThucThanhLy] = useState('');
//   const [maNguoiDung] = useState(localStorage.getItem('maNguoiDung')); // Lấy mã người dùng từ localStorage
//   const [error, setError] = useState('');

//   // Hàm gửi yêu cầu tạo phiếu thanh lý
//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     setError(''); // Reset error

//     if (!lyDo || !trangThai || !phuongThucThanhLy) {
//       setError('Vui lòng điền đầy đủ thông tin');
//       return;
//     }

//     const newPhieu = {
//       LyDo: lyDo,
//       TrangThai: trangThai,
//       PhuongThucThanhLy: phuongThucThanhLy,
//       MaNguoiDung: maNguoiDung,  // Gửi mã người dùng từ localStorage
//     };

//     try {
//       const response = await axios.post('https://localhost:7240/api/PhieuThanhLy', newPhieu);
//       alert('Tạo phiếu thanh lý thành công!');
//       onRefresh(); // Làm mới danh sách
//       onClose();   // Đóng form
//     } catch (error) {
//       console.error('Có lỗi khi tạo phiếu thanh lý:', error);
//       setError('Có lỗi khi tạo phiếu thanh lý, vui lòng thử lại.');
//     }
//   };

//   return (
//     <div className="modal">
//       <div className="modal-content p-8 bg-white rounded-lg shadow-lg">
//         <h2 className="text-2xl font-bold mb-6">Tạo Phiếu Thanh Lý</h2>
        
//         {/* Hiển thị lỗi nếu có */}
//         {error && <div className="text-red-500 mb-4">{error}</div>}

//         <form onSubmit={handleSubmit}>
//           <div className="mb-4">
//             <label htmlFor="lyDo" className="block text-sm font-medium text-gray-700">Lý Do</label>
//             <input
//               type="text"
//               id="lyDo"
//               value={lyDo}
//               onChange={(e) => setLyDo(e.target.value)}
//               className="mt-1 block w-full px-4 py-2 border rounded-md"
//               required
//             />
//           </div>

//           <div className="mb-4">
//             <label htmlFor="trangThai" className="block text-sm font-medium text-gray-700">Trạng Thái</label>
//             <input
//               type="text"
//               id="trangThai"
//               value={trangThai}
//               onChange={(e) => setTrangThai(e.target.value)}
//               className="mt-1 block w-full px-4 py-2 border rounded-md"
//               required
//             />
//           </div>

//           <div className="mb-4">
//             <label htmlFor="phuongThucThanhLy" className="block text-sm font-medium text-gray-700">Phương Thức Thanh Lý</label>
//             <input
//               type="text"
//               id="phuongThucThanhLy"
//               value={phuongThucThanhLy}
//               onChange={(e) => setPhuongThucThanhLy(e.target.value)}
//               className="mt-1 block w-full px-4 py-2 border rounded-md"
//               required
//             />
//           </div>

//           {/* Mã người dùng tự động lấy từ localStorage và không thể chỉnh sửa */}
//           <div className="mb-6">
//             <label htmlFor="maNguoiDung" className="block text-sm font-medium text-gray-700">Mã Người Dùng</label>
//             <input
//               type="text"
//               id="maNguoiDung"
//               value={maNguoiDung} // Đặt giá trị mã người dùng là giá trị lấy từ localStorage
//               readOnly // Không cho phép chỉnh sửa
//               className="mt-1 block w-full px-4 py-2 border rounded-md bg-gray-100"
//             />
//           </div>

//           <div className="flex justify-end space-x-4">
//             <button
//               type="button"
//               onClick={onClose}
//               className="bg-gray-500 text-white px-6 py-2 rounded-md"
//             >
//               Hủy
//             </button>
//             <button
//               type="submit"
//               className="bg-blue-500 text-white px-6 py-2 rounded-md"
//             >
//               Lưu
//             </button>
//           </div>
//         </form>
//       </div>
//     </div>
//   );
// };

// export default CreatePhieuThanhLyForm;
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const CreatePhieuThanhLyForm = ({ initialData, onClose, onRefresh }) => {
  const [lyDo, setLyDo] = useState(initialData?.lyDo || "");
  const [trangThai, setTrangThai] = useState(initialData?.trangThai || "");
  const [phuongThucThanhLy, setPhuongThucThanhLy] = useState(initialData?.phuongThucThanhLy || "");
  const [maNguoiDung, setMaNguoiDung] = useState(localStorage.getItem("maNguoiDung") || "");

  // Xử lý gửi form
  const handleSubmit = async (e) => {
    e.preventDefault();

    const data = { lyDo, trangThai, phuongThucThanhLy, maNguoiDung };

    try {
      if (initialData) {
        // Nếu có dữ liệu (edit)
        await axios.put(`https://localhost:7240/api/PhieuThanhLy/${initialData.maPhieuTL}`, data);
        alert('Cập nhật phiếu thanh lý thành công');
      } else {
        // Nếu không có dữ liệu (tạo mới)
        await axios.post('https://localhost:7240/api/PhieuThanhLy', data);
        alert('Tạo phiếu thanh lý thành công');
      }
      onRefresh(); // Làm mới danh sách sau khi tạo hoặc sửa
      onClose(); // Đóng form
    } catch (error) {
      console.error("Có lỗi khi cập nhật/ tạo phiếu thanh lý:", error);
      alert("Lỗi khi thực hiện thao tác.");
    }
  };

  return (
    <div className="modal">
      <div className="modal-content p-8 bg-white rounded-lg shadow-lg">
        <h2 className="text-2xl font-bold mb-6">{initialData ? "Cập Nhật Phiếu Thanh Lý" : "Tạo Phiếu Thanh Lý"}</h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label htmlFor="lyDo" className="block text-sm font-medium text-gray-700">Lý Do</label>
            <input
              type="text"
              id="lyDo"
              value={lyDo}
              onChange={(e) => setLyDo(e.target.value)}
              className="mt-1 block w-full px-4 py-2 border rounded-md"
              required
            />
          </div>
          <div className="mb-4">
            <label htmlFor="trangThai" className="block text-sm font-medium text-gray-700">Trạng Thái</label>
            <input
              type="text"
              id="trangThai"
              value={trangThai}
              onChange={(e) => setTrangThai(e.target.value)}
              className="mt-1 block w-full px-4 py-2 border rounded-md"
              required
            />
          </div>
          <div className="mb-4">
            <label htmlFor="phuongThucThanhLy" className="block text-sm font-medium text-gray-700">Phương Thức Thanh Lý</label>
            <input
              type="text"
              id="phuongThucThanhLy"
              value={phuongThucThanhLy}
              onChange={(e) => setPhuongThucThanhLy(e.target.value)}
              className="mt-1 block w-full px-4 py-2 border rounded-md"
              required
            />
          </div>
          <div className="mb-6">
            <label htmlFor="maNguoiDung" className="block text-sm font-medium text-gray-700">Mã Người Dùng</label>
            <input
              type="number"
              id="maNguoiDung"
              value={maNguoiDung}
              onChange={(e) => setMaNguoiDung(e.target.value)}
              className="mt-1 block w-full px-4 py-2 border rounded-md"
              disabled // Mã người dùng không thể sửa
            />
          </div>
          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={onClose}
              className="bg-gray-500 text-white px-6 py-2 rounded-md"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="bg-blue-500 text-white px-6 py-2 rounded-md"
            >
              Lưu
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreatePhieuThanhLyForm;
