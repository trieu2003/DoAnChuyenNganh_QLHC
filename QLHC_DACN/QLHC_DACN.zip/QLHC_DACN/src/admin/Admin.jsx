
const Admin = () => {
    return <div>Trang admin</div>;
  };
  
  export default Admin;
  